f2py -c -m proteinlib proteinlib.f90 --fcompiler=gnu95
f2py -c -m geometrylib geometrylib.f90 --fcompiler=gnu95
f2py -c -m whamlib whamlib.f90 --fcompiler=gnu95

